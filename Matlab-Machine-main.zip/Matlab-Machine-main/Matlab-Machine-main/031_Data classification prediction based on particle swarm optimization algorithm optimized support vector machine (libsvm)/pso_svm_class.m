function [bestCVaccuarcy, bestc, bestg, pso_option] = pso_svm_class(t_train, p_train, pso_option)

%%  ������ʼ��
if nargin == 2
    pso_option = struct('c1', 1.5, 'c2', 1.7, 'maxgen', 10, 'sizepop', 10, ...
        'k', 0.6, 'wV', 1, 'wP', 1, 'v', 5, ...
        'popcmax', 10, 'popcmin', 10^(-1), 'popgmax', 10, 'popgmin', 10^(-1));
end

%%  ��������ٶ�
Vcmax = pso_option.k * pso_option.popcmax;
Vcmin = -Vcmax ;
Vgmax = pso_option.k * pso_option.popgmax;
Vgmin = -Vgmax ;

%%  �����ֵ
eps = 10^(-10);

%%  ��Ⱥ��ʼ��
for i = 1 : pso_option.sizepop
    
    % ���������Ⱥ���ٶ�
    pop(i, 1) = (pso_option.popcmax - pso_option.popcmin) * rand + pso_option.popcmin;
    pop(i, 2) = (pso_option.popgmax - pso_option.popgmin) * rand + pso_option.popgmin;
    V(i, 1) = Vcmax * rands(1, 1);
    V(i, 2) = Vgmax * rands(1, 1);
    
    % �����ʼ��Ӧ��
    cmd = [' -v ', num2str(pso_option.v), ' -c ',num2str(pop(i, 1)), ' -g ', num2str(pop(i, 2))];
    fitness(i) = (100 - svmtrain(t_train, p_train, cmd)) / 100;
end

%%  ��ʼ����ֵ�ͼ�ֵ��
[global_fitness, bestindex] = min(fitness);   % ȫ�ּ�ֵ
local_fitness = fitness;                      % ���弫ֵ��ʼ��
global_x = pop(bestindex, :);                 % ȫ�ּ�ֵ��
local_x = pop;                                % ���弫ֵ���ʼ��

%%  ƽ����Ӧ��
avgfitness_gen = zeros(1, pso_option.maxgen);

%%  ����Ѱ��
for i = 1 : pso_option.maxgen
    for j = 1 : pso_option.sizepop
        
       % �ٶȸ���
        V(j, :) = pso_option.wV * V(j, :) + pso_option.c1 * rand * (local_x(j, :) ...
            - pop(j, :)) + pso_option.c2 * rand * (global_x - pop(j, :));
        
        if V(j, 1) > Vcmax
           V(j, 1) = Vcmax;
        end

        if V(j, 1) < Vcmin
           V(j, 1) = Vcmin;
        end

        if V(j, 2) > Vgmax
           V(j, 2) = Vgmax;
        end

        if V(j, 2) < Vgmin
           V(j, 2) = Vgmin;
        end
        
       % ��Ⱥ����
        pop(j, :) = pop(j, :) + pso_option.wP * V(j, :);

        if pop(j, 1) > pso_option.popcmax
           pop(j, 1) = pso_option.popcmax;
        end

        if pop(j, 1) < pso_option.popcmin
           pop(j, 1) = pso_option.popcmin;
        end

        if pop(j, 2) > pso_option.popgmax
           pop(j, 2) = pso_option.popgmax;
        end

        if pop(j, 2) < pso_option.popgmin
           pop(j, 2) = pso_option.popgmin;
        end
        
       % ����Ӧ���ӱ���
        if rand > 0.5
            k = ceil(2 * rand);

            if k == 1
                pop(j, k) = (20 - 1) * rand + 1;
            end
            
            if k == 2
                pop(j, k) = (pso_option.popgmax - pso_option.popgmin) * rand + pso_option.popgmin;
            end

        end
        
       % ��Ӧ��ֵ
       cmd = [' -v ', num2str(pso_option.v), ' -c ', num2str(pop(j, 1)), ' -g ', num2str(pop(j, 2))];
       fitness(j) = (100 - svmtrain(t_train, p_train, cmd)) / 100;
        
       % �������Ÿ���
        if fitness(j) < local_fitness(j)
            local_x(j, :) = pop(j, :);
            local_fitness(j) = fitness(j);
        end
        
        if abs(fitness(j)-local_fitness(j)) <= eps && pop(j, 1) < local_x(j, 1)
            local_x(j, :) = pop(j, :);
            local_fitness(j) = fitness(j);
        end
        
       % Ⱥ�����Ÿ���
        if fitness(j) < global_fitness
            global_x = pop(j, :);
            global_fitness = fitness(j);
        end
        
        if abs(fitness(j) - global_fitness) <= eps && pop(j, 1) < global_x(1)
            global_x = pop(j, :);
            global_fitness = fitness(j);
        end
        
    end
    
    % ƽ����Ӧ�Ⱥ������Ӧ��
    fit_gen(i) = global_fitness;
    avgfitness_gen(i) = sum(fitness) / pso_option.sizepop;

end

%%  ��Ӧ������
figure
plot(1 : length(fit_gen), fit_gen, 'b-', 'LineWidth', 1.5);
title ('��Ӧ������', 'FontSize', 13)
xlabel('��������', 'FontSize', 10)
ylabel('��Ӧ��', 'FontSize', 10)
grid on

%%  ����ֵ��ֵ
bestc = global_x(1);
bestg = global_x(2);
bestCVaccuarcy = (1 - fit_gen(pso_option.maxgen)) * 100;